package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.dto.BoardDto.DeleteDto;
import com.example.demo.dto.BoardDto.UpdateDto;
import com.example.demo.dto.BoardDto.WriteDto;
import com.example.demo.entity.Board;
import com.example.demo.service.BoardService;

@SpringBootTest
public class BoardServiceTest {
	@Autowired
	BoardService service;
	@Transactional
//	@Test
	public void writeTest() {
		WriteDto dto = WriteDto.builder().title("xxx").content("yyy").writer("sss").password("1234").build();
		Board result = service.save(dto);
		System.out.println(result);
	}
	//@Test
	public void readTest() {
		System.out.println(service.findById(1));
		assertEquals(true, service.findById(1).isPresent());
		assertEquals(true, service.findById(1111).isEmpty());
	}
	@Test
	public void updateTest() {
		UpdateDto d = UpdateDto.builder().title("xxx123").content("x32123xz").bno(1).password("1234").build();
		assertEquals(true, service.update(d));
	}
	//@Transactional
	//@Test
	public void deleteTest() {
		//DeleteDto d = DeleteDto.builder().bno(1).password("1234").build();
		//DeleteDto d2 = DeleteDto.builder().bno(81).password("1234").build();
		DeleteDto d3 = DeleteDto.builder().bno(1).password("134").build();
		//assertEquals(true, service.deleteById(d));
		//assertEquals(false, service.deleteById(d2));
		assertEquals(false, service.deleteById(d3));
	}
}
